package es.iessaladillo.rafamartinez.supermanzanares.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [ProductEntity::class, CartItemEntity::class, ShoppingListItemEntity::class, ShoppingListEntity::class, CategoryEntity::class],
    version = 13,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun shoppingListDao(): ShoppingListDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            val instance = Room.databaseBuilder(
                        context.applicationContext, AppDatabase::class.java, "supermanzanares_db"
                    ).fallbackToDestructiveMigration(false).build()
            INSTANCE = instance
            instance
        }
    }
}
