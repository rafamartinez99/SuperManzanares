package es.iessaladillo.rafamartinez.supermanzanares.data.repository

import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import es.iessaladillo.rafamartinez.supermanzanares.data.local.ProductDao
import es.iessaladillo.rafamartinez.supermanzanares.data.local.toDomain
import es.iessaladillo.rafamartinez.supermanzanares.data.local.toEntity
import es.iessaladillo.rafamartinez.supermanzanares.data.model.NutritionInfo
import es.iessaladillo.rafamartinez.supermanzanares.data.remote.FirebaseService
import es.iessaladillo.rafamartinez.supermanzanares.data.model.Product
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class ProductRepository @Inject constructor(
    private val productDao: ProductDao, private val firebaseService: FirebaseService
) {
    private val defaultProducts = listOf(
        Product(
            id = "p1",
            name = "Leche entera Pascual 1L",
            imageUrl = "https://i.imgur.com/I7uCWXY.png",
            price = 1.25,
            weight = 1.0,
            originalPrice = 1.45,
            discountPrice = 1.25,
            description = "Leche entera UHT de alta calidad ideal para desayunos, postres o beber sola.",
            categoryId = 1,
            ingredients = listOf("Leche entera de vaca", "Estabilizante (E-407)", "Vitamina D"),
            nutrition = NutritionInfo(
                energyKcal = 64,
                fats = 3.6,
                saturatedFats = 2.4,
                carbohydrates = 4.7,
                sugars = 4.7,
                fiber = 0.0,
                protein = 3.2,
                salt = 0.1
            )
        ), Product(
            id = "p2",
            name = "Yogur natural 125g",
            imageUrl = "https://i.imgur.com/Yshi3fj.png",
            price = 0.49,
            weight = 0.125,
            originalPrice = 0.59,
            discountPrice = 0.49,
            description = "Yogur natural cremoso fermentado con cultivos vivos.",
            categoryId = 1,
            ingredients = listOf(
                "Leche entera",
                "Fermentos lácticos (Lactobacillus bulgaricus, Streptococcus thermophilus)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 63,
                fats = 3.5,
                saturatedFats = 2.3,
                carbohydrates = 4.7,
                sugars = 4.7,
                fiber = 0.0,
                protein = 3.8,
                salt = 0.1
            )
        ), Product(
            id = "p3",
            name = "Queso manchego curado 250g",
            imageUrl = "https://i.imgur.com/52nCDdM.png",
            price = 3.99,
            weight = 0.25,
            originalPrice = 4.39,
            discountPrice = 3.99,
            description = "Queso manchego curado con leche de oveja, sabor intenso y maduración prolongada.",
            categoryId = 1,
            ingredients = listOf(
                "Leche cruda de oveja", "Cuajo", "Cloruro cálcico", "Fermentos lácticos", "Sal"
            ),
            nutrition = NutritionInfo(
                energyKcal = 416,
                fats = 35.0,
                saturatedFats = 25.0,
                carbohydrates = 1.0,
                sugars = 0.1,
                fiber = 0.0,
                protein = 25.0,
                salt = 1.8
            )
        ), Product(
            id = "p4",
            name = "Mantequilla sin sal 250g",
            imageUrl = "https://i.imgur.com/mw1vFwT.png",
            price = 2.39,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Mantequilla elaborada con nata pasteurizada sin sal añadida.",
            categoryId = 1,
            ingredients = listOf("Nata pasteurizada de leche", "Fermentos lácticos"),
            nutrition = NutritionInfo(
                energyKcal = 745,
                fats = 82.0,
                saturatedFats = 52.0,
                carbohydrates = 0.5,
                sugars = 0.5,
                fiber = 0.0,
                protein = 0.6,
                salt = 0.02
            )
        ), Product(
            id = "p5",
            name = "Pan de molde integral 500g",
            imageUrl = "https://i.imgur.com/t01YEfn.png",
            price = 1.49,
            weight = 0.5,
            originalPrice = null,
            discountPrice = null,
            description = "Pan de molde integral rico en fibra, ideal para desayunos y meriendas.",
            categoryId = 2,
            ingredients = listOf(
                "Harina integral de trigo",
                "Agua",
                "Gluten de trigo",
                "Levadura",
                "Sal",
                "Aceite vegetal (girasol)",
                "Vinagre",
                "Azúcar",
                "Emulgente (E-472e)",
                "Conservador (E-282)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 240,
                fats = 3.4,
                saturatedFats = 0.4,
                carbohydrates = 42.0,
                sugars = 4.1,
                fiber = 6.8,
                protein = 9.2,
                salt = 1.1
            )
        ), Product(
            id = "p6",
            name = "Croissant de mantequilla",
            imageUrl = "https://i.imgur.com/746aJe5.png",
            price = 0.95,
            weight = 0.1,
            originalPrice = null,
            discountPrice = null,
            description = "Crujiente croissant de mantequilla con masa hojaldrada tradicional.",
            categoryId = 2,
            ingredients = listOf(
                "Harina de trigo",
                "Mantequilla (leche)",
                "Agua",
                "Levadura",
                "Azúcar",
                "Huevos",
                "Sal",
                "Gluten de trigo",
                "Emulgente (E-471)",
                "Conservador (E-200)",
                "Colorante (E-160a)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 406,
                fats = 21.0,
                saturatedFats = 13.0,
                carbohydrates = 45.0,
                sugars = 9.0,
                fiber = 2.0,
                protein = 7.5,
                salt = 0.9
            )
        ), Product(
            id = "p7",
            name = "Pechuga de pollo 1kg",
            imageUrl = "https://i.imgur.com/hAug8fE.png",
            price = 5.49,
            weight = 1.0,
            originalPrice = 6.49,
            discountPrice = 5.49,
            description = "Pechuga de pollo fresca y sin piel, fuente natural de proteínas.",
            categoryId = 3,
            ingredients = listOf("Pechuga de pollo"),
            nutrition = NutritionInfo(
                energyKcal = 110,
                fats = 1.5,
                saturatedFats = 0.3,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 24.0,
                salt = 0.1
            )
        ), Product(
            id = "p8",
            name = "Chorizo ibérico 250g",
            imageUrl = "https://i.imgur.com/PmNFRY8.png",
            price = 3.99,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Chorizo ibérico curado con especias naturales y aditivos conservantes.",
            categoryId = 3,
            ingredients = listOf(
                "Carne de cerdo ibérico",
                "Grasa de cerdo ibérico",
                "Pimentón",
                "Sal",
                "Azúcar",
                "Proteína de soja",
                "Dextrosa",
                "Ajo",
                "Antioxidante (E-301)",
                "Conservador (E-252)",
                "Colorante (E-120)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 455,
                fats = 38.0,
                saturatedFats = 14.0,
                carbohydrates = 1.5,
                sugars = 1.0,
                fiber = 0.0,
                protein = 26.0,
                salt = 2.3
            )
        ), Product(
            id = "p9",
            name = "Filete de salmón 200g",
            imageUrl = "https://i.imgur.com/oXjVd2D.png",
            price = 4.49,
            weight = 0.2,
            originalPrice = 4.99,
            discountPrice = 4.49,
            description = "Filete de salmón fresco, rico en ácidos grasos omega 3.",
            categoryId = 4,
            ingredients = listOf("Salmón"),
            nutrition = NutritionInfo(
                energyKcal = 208,
                fats = 13.0,
                saturatedFats = 3.1,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 20.0,
                salt = 0.1
            )
        ), Product(
            id = "p10",
            name = "Gambas peladas 250g",
            imageUrl = "https://i.imgur.com/AlMaaCT.png",
            price = 5.25,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Gambas peladas ultracongeladas, perfectas para guisos y paellas.",
            categoryId = 4,
            ingredients = listOf(
                "Gambas",
                "Antioxidante (E-330)",
                "Estabilizante (E-451)",
                "Corrector de acidez (E-331)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 90,
                fats = 1.0,
                saturatedFats = 0.2,
                carbohydrates = 0.2,
                sugars = 0.1,
                fiber = 0.0,
                protein = 20.0,
                salt = 1.2
            )
        ), Product(
            id = "p11",
            name = "Manzanas Golden 1kg",
            imageUrl = "https://i.imgur.com/VEyGGEP.png",
            price = 1.89,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Manzanas Golden frescas, dulces y crujientes, ideales para comer solas o en ensaladas.",
            categoryId = 5,
            ingredients = listOf("Manzana Golden"),
            nutrition = NutritionInfo(
                energyKcal = 52,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 14.0,
                sugars = 10.0,
                fiber = 2.4,
                protein = 0.3,
                salt = 0.0
            )
        ),

        Product(
            id = "p12",
            name = "Plátanos de Canarias 1kg",
            imageUrl = "https://i.imgur.com/KUm7axt.png",
            price = 2.05,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Plátanos de Canarias con denominación de origen, dulces y ricos en potasio.",
            categoryId = 5,
            ingredients = listOf("Plátano de Canarias"),
            nutrition = NutritionInfo(
                energyKcal = 89,
                fats = 0.3,
                saturatedFats = 0.1,
                carbohydrates = 23.0,
                sugars = 12.0,
                fiber = 2.6,
                protein = 1.1,
                salt = 0.0
            )
        ),

        Product(
            id = "p13",
            name = "Tomates pera 1kg",
            imageUrl = "https://i.imgur.com/JtUDG7l.png",
            price = 1.69,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Tomates pera rojos, carnosos y dulces, ideales para salsas o ensaladas.",
            categoryId = 5,
            ingredients = listOf("Tomate pera"),
            nutrition = NutritionInfo(
                energyKcal = 18,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 3.9,
                sugars = 2.6,
                fiber = 1.2,
                protein = 0.9,
                salt = 0.0
            )
        ),

        Product(
            id = "p14",
            name = "Atún en aceite de oliva 3x80g",
            imageUrl = "https://i.imgur.com/p2ijIz2.png",
            price = 4.15,
            weight = 0.24,
            originalPrice = 4.45,
            discountPrice = 4.15,
            description = "Lomos de atún claro en aceite de oliva, conservado para mantener todo su sabor.",
            categoryId = 6,
            ingredients = listOf("Atún claro", "Aceite de oliva", "Sal"),
            nutrition = NutritionInfo(
                energyKcal = 198,
                fats = 11.0,
                saturatedFats = 1.8,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 24.0,
                salt = 1.2
            )
        ),

        Product(
            id = "p15",
            name = "Maíz dulce en lata 150g",
            imageUrl = "https://i.imgur.com/oSohMa0.png",
            price = 1.25,
            weight = 0.15,
            originalPrice = null,
            discountPrice = null,
            description = "Maíz dulce en grano, cocido y listo para consumir. Ideal para ensaladas.",
            categoryId = 6,
            ingredients = listOf("Maíz dulce", "Agua", "Azúcar", "Sal"),
            nutrition = NutritionInfo(
                energyKcal = 90,
                fats = 1.2,
                saturatedFats = 0.2,
                carbohydrates = 18.0,
                sugars = 6.0,
                fiber = 2.0,
                protein = 2.5,
                salt = 0.6
            )
        ),

        Product(
            id = "p16",
            name = "Espaguetis 500g",
            imageUrl = "https://i.imgur.com/FTB1DPl.png",
            price = 1.15,
            weight = 0.5,
            originalPrice = 1.29,
            discountPrice = 1.15,
            description = "Espaguetis de trigo duro de calidad superior, perfectos para todo tipo de recetas.",
            categoryId = 7,
            ingredients = listOf("Sémola de trigo duro", "Agua"),
            nutrition = NutritionInfo(
                energyKcal = 359,
                fats = 1.5,
                saturatedFats = 0.3,
                carbohydrates = 73.0,
                sugars = 3.0,
                fiber = 3.2,
                protein = 12.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p17",
            name = "Macarrones 500g",
            imageUrl = "https://i.imgur.com/verVI57.png",
            price = 1.19,
            weight = 0.5,
            originalPrice = null,
            discountPrice = null,
            description = "Macarrones elaborados con trigo duro. Tiempo de cocción ideal: 8 minutos.",
            categoryId = 7,
            ingredients = listOf("Sémola de trigo duro", "Agua"),
            nutrition = NutritionInfo(
                energyKcal = 359,
                fats = 1.5,
                saturatedFats = 0.3,
                carbohydrates = 73.0,
                sugars = 3.0,
                fiber = 3.2,
                protein = 12.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p18",
            name = "Aceite de oliva virgen extra 1L",
            imageUrl = "https://i.imgur.com/FghVyFA.png",
            price = 4.95,
            weight = 1.0,
            originalPrice = 5.95,
            discountPrice = 4.95,
            description = "Aceite de oliva virgen extra de primera extracción en frío.",
            categoryId = 8,
            ingredients = listOf("Aceite de oliva virgen extra"),
            nutrition = NutritionInfo(
                energyKcal = 900,
                fats = 100.0,
                saturatedFats = 14.0,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.0,
                salt = 0.0
            )
        ),

        Product(
            id = "p19",
            name = "Vinagre de vino tinto 750ml",
            imageUrl = "https://i.imgur.com/jieqZxv.png",
            price = 1.45,
            weight = 0.75,
            originalPrice = null,
            discountPrice = null,
            description = "Vinagre de vino tinto con sabor intenso, ideal para aliñar ensaladas.",
            categoryId = 8,
            ingredients = listOf("Vinagre de vino tinto", "Conservador (E-224)"),
            nutrition = NutritionInfo(
                energyKcal = 6,
                fats = 0.0,
                saturatedFats = 0.0,
                carbohydrates = 0.2,
                sugars = 0.1,
                fiber = 0.0,
                protein = 0.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p20",
            name = "Judías verdes en lata 200g",
            imageUrl = "https://i.imgur.com/qv2uChE.png",
            price = 0.9,
            weight = 0.2,
            originalPrice = null,
            discountPrice = null,
            description = "Judías verdes extra en conserva, cocidas al punto y listas para consumir.",
            categoryId = 6,
            ingredients = listOf("Judías verdes", "Agua", "Sal", "Antioxidante (E-300)"),
            nutrition = NutritionInfo(
                energyKcal = 24,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 3.6,
                sugars = 1.2,
                fiber = 2.6,
                protein = 1.2,
                salt = 0.6
            )
        ), Product(
            id = "p21",
            name = "Judías verdes en lata 400g",
            imageUrl = "https://i.imgur.com/qv2uChE.png",
            price = 1.39,
            weight = 0.4,
            originalPrice = null,
            discountPrice = null,
            description = "Judías verdes extra en conserva, cocidas al punto y listas para consumir.",
            categoryId = 6,
            ingredients = listOf("Judías verdes", "Agua", "Sal", "Antioxidante (E-300)"),
            nutrition = NutritionInfo(
                energyKcal = 24,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 3.6,
                sugars = 1.2,
                fiber = 2.6,
                protein = 1.2,
                salt = 0.6
            )
        ),

        Product(
            id = "p22",
            name = "Garbanzos cocidos frasco 400g",
            imageUrl = "https://i.imgur.com/D8MWXkA.png",
            price = 1.05,
            weight = 0.4,
            originalPrice = null,
            discountPrice = null,
            description = "Garbanzos cocidos en conserva, listos para añadir a tus platos.",
            categoryId = 6,
            ingredients = listOf("Garbanzos", "Agua", "Sal", "Antioxidante (E-385)"),
            nutrition = NutritionInfo(
                energyKcal = 120,
                fats = 2.6,
                saturatedFats = 0.3,
                carbohydrates = 17.0,
                sugars = 0.6,
                fiber = 4.4,
                protein = 7.2,
                salt = 0.8
            )
        ),

        Product(
            id = "p23",
            name = "Cuscús 500g",
            imageUrl = "https://i.imgur.com/snqWHQ8.png",
            price = 1.95,
            weight = 0.5,
            originalPrice = 2.25,
            discountPrice = 1.95,
            description = "Cuscús de trigo duro precocido, ideal como guarnición o base de platos orientales.",
            categoryId = 7,
            ingredients = listOf("Sémola de trigo duro"),
            nutrition = NutritionInfo(
                energyKcal = 357,
                fats = 1.2,
                saturatedFats = 0.3,
                carbohydrates = 72.0,
                sugars = 1.0,
                fiber = 3.8,
                protein = 12.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p24",
            name = "Fideos finos 250g",
            imageUrl = "https://i.imgur.com/5mbME0c.png",
            price = 0.95,
            weight = 0.25,
            originalPrice = 1.15,
            discountPrice = 0.95,
            description = "Fideos finos de trigo ideales para sopas o fideuás.",
            categoryId = 7,
            ingredients = listOf("Sémola de trigo duro"),
            nutrition = NutritionInfo(
                energyKcal = 360,
                fats = 1.5,
                saturatedFats = 0.3,
                carbohydrates = 74.0,
                sugars = 2.5,
                fiber = 3.0,
                protein = 11.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p25",
            name = "Aceite de girasol 1L",
            imageUrl = "https://i.imgur.com/8JnP6hy.png",
            price = 2.99,
            weight = 1.0,
            originalPrice = 3.15,
            discountPrice = 2.99,
            description = "Aceite de girasol refinado, ideal para freír y cocinar.",
            categoryId = 8,
            ingredients = listOf("Aceite de girasol refinado"),
            nutrition = NutritionInfo(
                energyKcal = 884,
                fats = 100.0,
                saturatedFats = 11.0,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.0,
                salt = 0.0
            )
        ),

        Product(
            id = "p26",
            name = "Sal fina 1kg",
            imageUrl = "https://i.imgur.com/Rxw2TVw.png",
            price = 0.45,
            weight = 1.0,
            originalPrice = 0.59,
            discountPrice = 0.45,
            description = "Sal fina yodada para uso diario en cocina.",
            categoryId = 8,
            ingredients = listOf("Cloruro sódico", "Antiaglomerante (E-535)", "Yodato potásico"),
            nutrition = NutritionInfo(
                energyKcal = 0,
                fats = 0.0,
                saturatedFats = 0.0,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.0,
                salt = 100.0
            )
        ),

        Product(
            id = "p27",
            name = "Pimienta negra molida 50g",
            imageUrl = "https://i.imgur.com/SKs40Gb.png",
            price = 1.75,
            weight = 0.05,
            originalPrice = 1.99,
            discountPrice = 1.75,
            description = "Pimienta negra molida con aroma intenso, perfecta para sazonar carnes, pescados y verduras.",
            categoryId = 8,
            ingredients = listOf("Pimienta negra molida"),
            nutrition = NutritionInfo(
                energyKcal = 255,
                fats = 3.3,
                saturatedFats = 1.4,
                carbohydrates = 64.8,
                sugars = 0.6,
                fiber = 26.5,
                protein = 10.9,
                salt = 0.05
            )
        ),

        Product(
            id = "p28",
            name = "Manzana roja 1kg",
            imageUrl = "https://i.imgur.com/f194RPI.png",
            price = 1.99,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Manzanas rojas dulces y crujientes, perfectas como tentempié natural.",
            categoryId = 5,
            ingredients = listOf("Manzana roja"),
            nutrition = NutritionInfo(
                energyKcal = 50,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 13.0,
                sugars = 10.0,
                fiber = 2.2,
                protein = 0.3,
                salt = 0.0
            )
        ),

        Product(
            id = "p29",
            name = "Naranjas 1kg",
            imageUrl = "https://i.imgur.com/ks1ILOG.png",
            price = 1.89,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Naranjas jugosas ideales para zumo o postre.",
            categoryId = 5,
            ingredients = listOf("Naranja"),
            nutrition = NutritionInfo(
                energyKcal = 47,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 12.0,
                sugars = 9.0,
                fiber = 2.4,
                protein = 0.9,
                salt = 0.0
            )
        ),

        Product(
            id = "p30",
            name = "Cebolla blanca 1kg",
            imageUrl = "https://i.imgur.com/wTnaoTJ.png",
            price = 1.25,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Cebolla blanca fresca con sabor suave, ideal para guisos y sofritos.",
            categoryId = 5,
            ingredients = listOf("Cebolla blanca"),
            nutrition = NutritionInfo(
                energyKcal = 40,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 9.3,
                sugars = 4.2,
                fiber = 1.7,
                protein = 1.1,
                salt = 0.01
            )
        ), Product(
            id = "p31",
            name = "Patatas lavadas 3kg",
            imageUrl = "https://i.imgur.com/f4G33u9.png",
            price = 3.29,
            weight = 3.0,
            originalPrice = null,
            discountPrice = null,
            description = "Patatas lavadas de calidad superior, ideales para freír, cocer o asar.",
            categoryId = 5,
            ingredients = listOf("Patatas"),
            nutrition = NutritionInfo(
                energyKcal = 77,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 17.0,
                sugars = 0.8,
                fiber = 2.2,
                protein = 2.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p32",
            name = "Huevos camperos 12ud",
            imageUrl = "https://i.imgur.com/gYJaZqW.png",
            price = 3.2,
            weight = 0.72,
            originalPrice = null,
            discountPrice = null,
            description = "Huevos camperos procedentes de gallinas criadas en libertad.",
            categoryId = 1,
            ingredients = listOf("Huevo campero clase M"),
            nutrition = NutritionInfo(
                energyKcal = 143,
                fats = 10.0,
                saturatedFats = 3.0,
                carbohydrates = 0.8,
                sugars = 0.4,
                fiber = 0.0,
                protein = 13.0,
                salt = 0.4
            )
        ),

        Product(
            id = "p33",
            name = "Tortilla de patatas 500g",
            imageUrl = "https://i.imgur.com/eKyPfN4.png",
            price = 3.85,
            weight = 0.5,
            originalPrice = null,
            discountPrice = null,
            description = "Tortilla de patatas tradicional con huevos y cebolla.",
            categoryId = 1,
            ingredients = listOf(
                "Huevo pasteurizado", "Patata", "Aceite de girasol", "Cebolla", "Sal"
            ),
            nutrition = NutritionInfo(
                energyKcal = 165,
                fats = 10.5,
                saturatedFats = 1.9,
                carbohydrates = 12.0,
                sugars = 1.2,
                fiber = 1.3,
                protein = 5.5,
                salt = 1.2
            )
        ),

        Product(
            id = "p34",
            name = "Pan rallado 250g",
            imageUrl = "https://i.imgur.com/NnryHPr.png",
            price = 1.15,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Pan rallado fino, ideal para rebozados y gratinados.",
            categoryId = 2,
            ingredients = listOf("Harina de trigo", "Agua", "Levadura", "Sal"),
            nutrition = NutritionInfo(
                energyKcal = 370,
                fats = 3.0,
                saturatedFats = 0.5,
                carbohydrates = 72.0,
                sugars = 4.5,
                fiber = 4.0,
                protein = 11.0,
                salt = 1.3
            )
        ),

        Product(
            id = "p35",
            name = "Donuts chocolate 4ud",
            imageUrl = "https://i.imgur.com/jKWGvon.png",
            price = 2.55,
            weight = 0.28,
            originalPrice = null,
            discountPrice = null,
            description = "Donuts cubiertos de chocolate, esponjosos y listos para disfrutar.",
            categoryId = 2,
            ingredients = listOf(
                "Harina de trigo",
                "Azúcar",
                "Aceite de palma",
                "Leche desnatada en polvo",
                "Cacao",
                "Huevos",
                "Gluten de trigo",
                "Levadura",
                "Sal",
                "Emulgentes (E-471, E-322)",
                "Colorante (E-160a)",
                "Aromas"
            ),
            nutrition = NutritionInfo(
                energyKcal = 450,
                fats = 24.0,
                saturatedFats = 12.0,
                carbohydrates = 50.0,
                sugars = 26.0,
                fiber = 2.0,
                protein = 6.0,
                salt = 0.9
            )
        ),

        Product(
            id = "p36",
            name = "Bacon ahumado 200g",
            imageUrl = "https://i.imgur.com/JWzns0T.png",
            price = 2.95,
            weight = 0.2,
            originalPrice = null,
            discountPrice = null,
            description = "Bacon ahumado en lonchas, perfecto para desayunos o acompañamientos.",
            categoryId = 3,
            ingredients = listOf(
                "Panceta de cerdo",
                "Sal",
                "Azúcar",
                "Estabilizantes (E-451, E-450)",
                "Antioxidante (E-301)",
                "Conservador (E-250)",
                "Aromas de humo"
            ),
            nutrition = NutritionInfo(
                energyKcal = 395,
                fats = 35.0,
                saturatedFats = 13.0,
                carbohydrates = 1.0,
                sugars = 1.0,
                fiber = 0.0,
                protein = 17.0,
                salt = 2.5
            )
        ),

        Product(
            id = "p37",
            name = "Alitas de pollo adobadas 1kg",
            imageUrl = "https://i.imgur.com/bEq6Tqf.png",
            price = 4.79,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Alitas de pollo adobadas con especias, listas para hornear o freír.",
            categoryId = 3,
            ingredients = listOf(
                "Alitas de pollo",
                "Sal",
                "Ajo",
                "Pimentón",
                "Orégano",
                "Conservador (E-262)",
                "Antioxidante (E-301)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 185,
                fats = 13.0,
                saturatedFats = 4.0,
                carbohydrates = 1.0,
                sugars = 0.5,
                fiber = 0.0,
                protein = 18.0,
                salt = 1.7
            )
        ),

        Product(
            id = "p38",
            name = "Pescadilla entera 1kg",
            imageUrl = "https://i.imgur.com/rlgciMR.png",
            price = 7.25,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Pescadilla entera fresca, limpia y lista para cocinar al horno o plancha.",
            categoryId = 4,
            ingredients = listOf("Pescadilla"),
            nutrition = NutritionInfo(
                energyKcal = 83,
                fats = 1.5,
                saturatedFats = 0.3,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 18.0,
                salt = 0.2
            )
        ),

        Product(
            id = "p39",
            name = "Mejillones cocidos 500g",
            imageUrl = "https://i.imgur.com/fYEr1OZ.png",
            price = 3.39,
            weight = 0.5,
            originalPrice = null,
            discountPrice = null,
            description = "Mejillones cocidos y listos para consumir, ricos en hierro y omega 3.",
            categoryId = 4,
            ingredients = listOf("Mejillones", "Sal", "Antioxidante (E-330)"),
            nutrition = NutritionInfo(
                energyKcal = 85,
                fats = 2.0,
                saturatedFats = 0.5,
                carbohydrates = 2.5,
                sugars = 0.5,
                fiber = 0.0,
                protein = 14.0,
                salt = 1.0
            )
        ),

        Product(
            id = "p40",
            name = "Té verde 20 bolsas",
            imageUrl = "https://i.imgur.com/KzwhplC.png",
            price = 1.69,
            weight = 0.04,
            originalPrice = null,
            discountPrice = null,
            description = "Té verde en bolsitas, ideal para tomar caliente o frío.",
            categoryId = 6,
            ingredients = listOf("Té verde 100%"),
            nutrition = NutritionInfo(
                energyKcal = 1,
                fats = 0.0,
                saturatedFats = 0.0,
                carbohydrates = 0.2,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.0,
                salt = 0.0
            )
        ), Product(
            id = "p41",
            name = "Café molido mezcla 250g",
            imageUrl = "https://i.imgur.com/XuOfRDq.png",
            price = 2.25,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Café molido mezcla de tueste natural y torrefacto, ideal para cafeteras italianas o de filtro.",
            categoryId = 6,
            ingredients = listOf("Café natural", "Café torrefacto (café, azúcar)"),
            nutrition = NutritionInfo(
                energyKcal = 1,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.1,
                salt = 0.0
            )
        ),

        Product(
            id = "p42",
            name = "Galletas maría 800g",
            imageUrl = "https://i.imgur.com/lne0yNw.png",
            price = 2.65,
            weight = 0.8,
            originalPrice = null,
            discountPrice = null,
            description = "Galletas maría clásicas, crujientes y ligeras. Perfectas para desayunos o meriendas.",
            categoryId = 2,
            ingredients = listOf(
                "Harina de trigo",
                "Azúcar",
                "Aceite de girasol alto oleico",
                "Suero de leche en polvo",
                "Gasificantes (E-500ii, E-503ii)",
                "Sal",
                "Aromas"
            ),
            nutrition = NutritionInfo(
                energyKcal = 437,
                fats = 11.0,
                saturatedFats = 1.3,
                carbohydrates = 75.0,
                sugars = 20.0,
                fiber = 2.5,
                protein = 6.5,
                salt = 0.6
            )
        ),

        Product(
            id = "p43",
            name = "Cacao soluble 1kg",
            imageUrl = "https://i.imgur.com/Bdrmitc.png",
            price = 3.9,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Cacao soluble con alto contenido en azúcares, ideal para disolver en leche caliente o fría.",
            categoryId = 6,
            ingredients = listOf(
                "Azúcar",
                "Cacao desgrasado en polvo (22%)",
                "Minerales (carbonato cálcico, hierro)",
                "Vitaminas (C, niacina, B6, B2, B1, ácido fólico, B12)",
                "Emulgente (lecitina de soja)",
                "Aromas"
            ),
            nutrition = NutritionInfo(
                energyKcal = 379,
                fats = 3.5,
                saturatedFats = 2.1,
                carbohydrates = 78.0,
                sugars = 74.0,
                fiber = 5.5,
                protein = 5.0,
                salt = 0.25
            )
        ),

        Product(
            id = "p44",
            name = "Zumo de naranja 1L",
            imageUrl = "https://i.imgur.com/zUVdEv2.png",
            price = 1.75,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Zumo de naranja a partir de concentrado, sin azúcares añadidos.",
            categoryId = 10,
            ingredients = listOf("Zumo de naranja a partir de concentrado", "Vitamina C"),
            nutrition = NutritionInfo(
                energyKcal = 45,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 10.0,
                sugars = 9.0,
                fiber = 0.2,
                protein = 0.7,
                salt = 0.01
            )
        ),

        Product(
            id = "p45",
            name = "Agua mineral 1.5L",
            imageUrl = "https://i.imgur.com/p449tp7.png",
            price = 0.65,
            weight = 1.5,
            originalPrice = null,
            discountPrice = null,
            description = "Agua mineral natural de manantial, baja en sodio y adecuada para dietas pobres en sal.",
            categoryId = 10,
            ingredients = listOf("Agua mineral natural"),
            nutrition = NutritionInfo(
                energyKcal = 0,
                fats = 0.0,
                saturatedFats = 0.0,
                carbohydrates = 0.0,
                sugars = 0.0,
                fiber = 0.0,
                protein = 0.0,
                salt = 0.0
            )
        ),

        Product(
            id = "p46",
            name = "Chocolate negro 70% 100g",
            imageUrl = "https://i.imgur.com/vXAFuAS.png",
            price = 1.99,
            weight = 0.1,
            originalPrice = null,
            discountPrice = null,
            description = "Chocolate negro con 70% de cacao, intenso y con bajo contenido en azúcar.",
            categoryId = 2,
            ingredients = listOf(
                "Pasta de cacao",
                "Azúcar",
                "Manteca de cacao",
                "Emulgente (lecitina de soja)",
                "Aroma natural de vainilla"
            ),
            nutrition = NutritionInfo(
                energyKcal = 540,
                fats = 38.0,
                saturatedFats = 23.0,
                carbohydrates = 29.0,
                sugars = 24.0,
                fiber = 11.0,
                protein = 7.0,
                salt = 0.01
            )
        ),

        Product(
            id = "p47",
            name = "Mermelada de fresa 350g",
            imageUrl = "https://i.imgur.com/w9MWVM5.png",
            price = 2.25,
            weight = 0.35,
            originalPrice = null,
            discountPrice = null,
            description = "Mermelada extra de fresa con un 50% de fruta. Perfecta para tostadas o repostería.",
            categoryId = 9,
            ingredients = listOf(
                "Fresas", "Azúcar", "Jugo de limón", "Gelificante (pectina)", "Conservador (E-202)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 247,
                fats = 0.3,
                saturatedFats = 0.0,
                carbohydrates = 60.0,
                sugars = 55.0,
                fiber = 1.0,
                protein = 0.5,
                salt = 0.03
            )
        ),

        Product(
            id = "p48",
            name = "Mayonesa 225ml",
            imageUrl = "https://i.imgur.com/f5a8DGW.png",
            price = 1.95,
            weight = 0.225,
            originalPrice = null,
            discountPrice = null,
            description = "Mayonesa cremosa elaborada con huevos pasteurizados y aceite de girasol.",
            categoryId = 8,
            ingredients = listOf(
                "Aceite de girasol (78%)",
                "Agua",
                "Yema de huevo pasteurizada (5%)",
                "Vinagre",
                "Azúcar",
                "Sal",
                "Antioxidantes (E-385)",
                "Estabilizante (E-412)",
                "Aromas"
            ),
            nutrition = NutritionInfo(
                energyKcal = 715,
                fats = 78.0,
                saturatedFats = 6.0,
                carbohydrates = 2.0,
                sugars = 1.5,
                fiber = 0.0,
                protein = 1.0,
                salt = 1.3
            )
        ),

        Product(
            id = "p49",
            name = "Ketchup 342g",
            imageUrl = "https://i.imgur.com/bZksFNC.png",
            price = 3.85,
            weight = 0.3,
            originalPrice = null,
            discountPrice = null,
            description = "Ketchup con tomate concentrado, sabor dulce y ligeramente ácido.",
            categoryId = 8,
            ingredients = listOf(
                "Concentrado de tomate (148g por 100g de ketchup)",
                "Azúcar",
                "Vinagre de alcohol",
                "Sal",
                "Especias",
                "Extracto de especias",
                "Aromas naturales"
            ),
            nutrition = NutritionInfo(
                energyKcal = 110,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 25.0,
                sugars = 22.0,
                fiber = 1.0,
                protein = 1.2,
                salt = 1.8
            )
        ),

        Product(
            id = "p50",
            name = "Mostaza 240g",
            imageUrl = "https://i.imgur.com/FU8mvHh.png",
            price = 1.75,
            weight = 0.2,
            originalPrice = null,
            discountPrice = null,
            description = "Mostaza tipo Dijon de sabor intenso, ideal para carnes y vinagretas.",
            categoryId = 8,
            ingredients = listOf(
                "Agua",
                "Semillas de mostaza",
                "Vinagre de alcohol",
                "Sal",
                "Acidulante (ácido cítrico)",
                "Conservador (E-224)"
            ),
            nutrition = NutritionInfo(
                energyKcal = 145,
                fats = 9.5,
                saturatedFats = 0.7,
                carbohydrates = 5.0,
                sugars = 2.0,
                fiber = 3.0,
                protein = 7.0,
                salt = 5.0
            )
        ), Product(
            id = "p51",
            name = "Ensalada mixta en bolsa 200g",
            imageUrl = "https://i.imgur.com/SUbT845.png",
            price = 1.59,
            weight = 0.2,
            originalPrice = null,
            discountPrice = null,
            description = "Ensalada mixta lavada y lista para consumir, ideal para ensaladas rápidas y frescas.",
            categoryId = 5,
            ingredients = listOf(
                "Lechuga iceberg", "Zanahoria rallada", "Escarola", "Col lombarda"
            ),
            nutrition = NutritionInfo(
                energyKcal = 22,
                fats = 0.2,
                saturatedFats = 0.0,
                carbohydrates = 3.6,
                sugars = 2.2,
                fiber = 2.4,
                protein = 1.1,
                salt = 0.02
            )
        ),

        Product(
            id = "p52",
            name = "Pepinos 1kg",
            imageUrl = "https://i.imgur.com/AqzKany.png",
            price = 1.35,
            weight = 1.0,
            originalPrice = null,
            discountPrice = null,
            description = "Pepinos frescos de textura crujiente, ideales para ensaladas o gazpachos.",
            categoryId = 5,
            ingredients = listOf("Pepino"),
            nutrition = NutritionInfo(
                energyKcal = 12,
                fats = 0.1,
                saturatedFats = 0.0,
                carbohydrates = 2.2,
                sugars = 1.3,
                fiber = 0.7,
                protein = 0.6,
                salt = 0.01
            )
        ),

        Product(
            id = "p53",
            name = "Yogur griego natural 2x125g",
            imageUrl = "https://i.imgur.com/sklPHjk.png",
            price = 1.49,
            weight = 0.25,
            originalPrice = null,
            discountPrice = null,
            description = "Yogur griego natural cremoso, ideal para postres o tomar solo.",
            categoryId = 9,
            ingredients = listOf(
                "Leche entera pasteurizada", "Nata", "Proteína de leche", "Fermentos lácticos"
            ),
            nutrition = NutritionInfo(
                energyKcal = 120,
                fats = 10.0,
                saturatedFats = 6.5,
                carbohydrates = 3.5,
                sugars = 3.5,
                fiber = 0.0,
                protein = 5.0,
                salt = 0.1
            )
        ),

        Product(
            id = "p54",
            name = "Tarta de queso 400g",
            imageUrl = "https://i.imgur.com/pS8tNrV.png",
            price = 4.75,
            weight = 0.4,
            originalPrice = null,
            discountPrice = null,
            description = "Tarta de queso tradicional con base de galleta y cobertura suave de queso.",
            categoryId = 9,
            ingredients = listOf(
                "Queso crema",
                "Huevos",
                "Nata",
                "Azúcar",
                "Leche",
                "Galleta (harina de trigo, aceite, azúcar)",
                "Mantequilla",
                "Gelatina"
            ),
            nutrition = NutritionInfo(
                energyKcal = 325,
                fats = 22.0,
                saturatedFats = 13.0,
                carbohydrates = 25.0,
                sugars = 18.0,
                fiber = 0.5,
                protein = 5.5,
                salt = 0.6
            )
        ),

        Product(
            id = "p55",
            name = "Pizza barbacoa congelada 400g",
            imageUrl = "https://i.imgur.com/oLuNCNJ.png",
            price = 3.25,
            weight = 0.4,
            originalPrice = 3.55,
            discountPrice = 3.25,
            description = "Pizza barbacoa congelada con carne, queso y salsa barbacoa.",
            categoryId = 2,
            ingredients = listOf(
                "Harina de trigo",
                "Agua",
                "Queso mozzarella",
                "Carne de cerdo",
                "Salsa barbacoa (agua, azúcar, vinagre, tomate, especias)",
                "Aceite de girasol",
                "Sal",
                "Levadura",
                "Azúcar"
            ),
            nutrition = NutritionInfo(
                energyKcal = 260,
                fats = 11.0,
                saturatedFats = 5.0,
                carbohydrates = 28.0,
                sugars = 18.0,
                fiber = 2.0,
                protein = 12.0,
                salt = 1.3
            )
        )
    )

    private val allProducts: Flow<List<Product>> =
        productDao.getAllProducts().map { list -> list.map { it.toDomain() } }


    suspend fun initProductsIfNeeded() {
        val localProducts =
            productDao.getAllProducts().firstOrNull().orEmpty().map { it.toDomain() }

        val remoteProducts = firebaseService.getProductsOnce()
        val remoteIds = remoteProducts.map { it.id }

        if (localProducts.isEmpty()) {
            when {
                remoteProducts.isNotEmpty() -> {
                    productDao.insertProducts(remoteProducts.map { it.toEntity() })
                }

                else -> {
                    productDao.insertProducts(defaultProducts.map { it.toEntity() })
                    defaultProducts.forEach { firebaseService.addProduct(it) }
                }
            }
            return
        }

        val newFromCode = defaultProducts.filter { it.id !in remoteIds }
        if (newFromCode.isNotEmpty()) {
            newFromCode.forEach { firebaseService.addProduct(it) }
            productDao.insertProducts(newFromCode.map { it.toEntity() })
        }

        val hasRemoteChanges = remoteProducts.any { remote ->
            val local = localProducts.find { it.id == remote.id }
            local == null || local != remote
        }
        if (hasRemoteChanges) {
            productDao.insertProducts(remoteProducts.map { it.toEntity() })
        }
    }

    fun observeFirestoreAndSyncToRoom(): Job = CoroutineScope(Dispatchers.IO).launch {
        firebaseService.getProducts().collect { remoteProducts ->
            val updatedEntities = remoteProducts.map { it.toEntity() }
            productDao.insertProducts(updatedEntities)
        }
    }

    fun getProducts(): Flow<List<Product>> = allProducts

    fun getProductById(productId: String): Flow<Product?> =
        productDao.getProductById(productId).map { it?.toDomain() }

    fun getProductsWithDiscount(): Flow<List<Product>> =
        allProducts.map { list -> list.filter { it.discountPrice != null } }

    fun getLatestProducts(): Flow<List<Product>> =
        allProducts.map { list -> list.takeLast(20) }

    fun getRelatedProducts(productId: String): Flow<List<Product>> =
        allProducts.map { list ->
            val current = list.find { it.id == productId }
            list.filter { it.id != productId && it.categoryId == current?.categoryId }
        }


}

